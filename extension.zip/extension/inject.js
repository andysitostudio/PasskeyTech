// Se ejecuta dentro de la página: intercepta navigator.credentials.create/get para ofrecer claves de acceso de PasskeyTech.
(() => {
  if (window.top !== window || window.__pk) return;
  const cr = navigator.credentials;
  if (!cr || !window.PublicKeyCredential) return;
  window.__pk = 1;
  const oc = cr.create.bind(cr), og = cr.get.bind(cr);
  const b2u = b => { const u = new Uint8Array(b instanceof ArrayBuffer ? b : b.buffer, b instanceof ArrayBuffer ? 0 : b.byteOffset, b.byteLength); let s = ''; u.forEach(c => (s += String.fromCharCode(c))); return btoa(s).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, ''); };
  const u2b = s => { s = s.replace(/-/g, '+').replace(/_/g, '/'); const r = atob(s + '='.repeat((4 - (s.length % 4)) % 4)), u = new Uint8Array(r.length); for (let i = 0; i < r.length; i++) u[i] = r.charCodeAt(i); return u.buffer; };
  const call = (op, data) => new Promise(res => {
    const id = Math.random().toString(36).slice(2) + Date.now();
    const h = e => { if (e.source === window && e.data && e.data.pkRes === id) { removeEventListener('message', h); res(e.data.r); } };
    addEventListener('message', h);
    postMessage({ pkReq: id, op, data }, location.origin);
  });
  const def = (o, p) => { for (const k in p) Object.defineProperty(o, k, { value: p[k], enumerable: true, configurable: true }); };
  const mk = (r, att) => {
    const resp = Object.create((att ? window.AuthenticatorAttestationResponse : window.AuthenticatorAssertionResponse).prototype), c = Object.create(PublicKeyCredential.prototype);
    def(resp, att ? { clientDataJSON: u2b(r.cdj), attestationObject: u2b(r.att), getTransports: () => ['internal'], getAuthenticatorData: () => u2b(r.ad), getPublicKey: () => u2b(r.pk), getPublicKeyAlgorithm: () => -7 }
      : { clientDataJSON: u2b(r.cdj), authenticatorData: u2b(r.ad), signature: u2b(r.sig), userHandle: r.uh ? u2b(r.uh) : null });
    def(c, { id: r.id, rawId: u2b(r.id), type: 'public-key', authenticatorAttachment: 'platform', response: resp, getClientExtensionResults: () => ({}),
      toJSON: () => ({ id: r.id, rawId: r.id, type: 'public-key', authenticatorAttachment: 'platform', clientExtensionResults: {},
        response: att ? { clientDataJSON: r.cdj, attestationObject: r.att, transports: ['internal'], authenticatorData: r.ad, publicKey: r.pk, publicKeyAlgorithm: -7 } : { clientDataJSON: r.cdj, authenticatorData: r.ad, signature: r.sig, userHandle: r.uh || undefined } }) });
    return c;
  };
  const deny = () => Promise.reject(new DOMException('The operation either timed out or was not allowed.', 'NotAllowedError'));
  cr.create = async function (o) {
    if (!o || !o.publicKey) return oc(o);
    try {
      const p = o.publicKey;
      const r = await call('create', { rpId: p.rp && p.rp.id, rpName: p.rp && p.rp.name, challenge: b2u(p.challenge), userId: b2u(p.user.id), userName: p.user.name || p.user.displayName,
        algs: (p.pubKeyCredParams || []).map(x => x.alg), exclude: (p.excludeCredentials || []).map(x => b2u(x.id)) });
      if (r && r.ok) return mk(r, true);
      if (r && r.cancel) return deny();
    } catch {}
    return oc(o);
  };
  cr.get = async function (o) {
    if (!o || !o.publicKey || o.mediation === 'conditional') return og(o);
    try {
      const p = o.publicKey;
      const r = await call('get', { rpId: p.rpId, challenge: b2u(p.challenge), allow: (p.allowCredentials || []).map(x => b2u(x.id)) });
      if (r && r.ok) return mk(r, false);
      if (r && r.cancel) return deny();
    } catch {}
    return og(o);
  };
})();
